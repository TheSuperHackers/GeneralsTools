Generals Big Creator for COMMAND AND CONQUER GENERALS: ZERO HOUR

Author:
xezon

GitHub:
https://github.com/xezon/GeneralsBigCreator

-----------------------------------------------------------------------------------------------
--- Install -----------------------------------------------------------------------------------

1. Run GeneralsBigCreator.exe


-----------------------------------------------------------------------------------------------
--- Changelog ---------------------------------------------------------------------------------

v1.0:
- Initial release

v1.1:
- Added -sourcewildcard, -prefixnames, -append command line options

v1.2
- Added messages for operation success and failure

v1.3
- Fixed issues with BIG file data read and write
