Generals Big Creator for COMMAND AND CONQUER GENERALS: ZERO HOUR

Author:
xezon

GitHub:
https://github.com/xezon/GeneralsBigCreator

-----------------------------------------------------------------------------------------------
--- Install -----------------------------------------------------------------------------------

1. Run GeneralsBigCreator.exe


-----------------------------------------------------------------------------------------------
--- Changelog ---------------------------------------------------------------------------------

v1.0:
- Initial release

v1.1:
- Added -sourcewildcard, -prefixnames, -append command line options
