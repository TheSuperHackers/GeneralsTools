Author: Eric Morin, Thomas Anderson

An addon that allows W3D files to be imported into 3dsMax8.

Copy Plugins, Scripts folders to C:\Program Files (x86)\Autodesk\3dsMax8

In 3dsMax8, go to menu Customize > Customize User Interface. Click the "Menu" tab. On the right you see +File, +Edit, +View, etc. The Plus signs are rollouts. Find the location amongst the menus you want the W3D Import command to go, for example next to "Import File" in the "File" menu. From the "Action" list on the left, find "Import a W3D File" and drag it to the location on the right where you want it in the menus.
